<?php
return array(
	'code'=>array(
		'title'=>'统计代码:',
		'type'=>'textarea',		 
		'value'=>'',			 
        'tip'=>'百度提供的访问分析代码'
	),
);