<?php

namespace Addons\AliPlay\Model;
use Think\Model;

/**
 * AliPlay模型
 */
class AliPlayModel extends Model{

}
