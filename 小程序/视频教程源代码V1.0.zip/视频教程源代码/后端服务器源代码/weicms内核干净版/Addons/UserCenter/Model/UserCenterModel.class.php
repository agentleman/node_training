<?php

namespace Addons\UserCenter\Model;
use Think\Model;

/**
 * UserCenter模型
 */
class UserCenterModel extends Model{

}
