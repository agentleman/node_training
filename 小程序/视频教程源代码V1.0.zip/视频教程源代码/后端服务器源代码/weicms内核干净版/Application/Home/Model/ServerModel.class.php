<?php

namespace Home\Model;

use Think\Model;

/**
 * 微信基础模型
 */
class ServerModel extends Model {
	
}